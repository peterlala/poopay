setTimeout(function () {
    document.getElementById("lst").style.display = "block";

  // 100%//
  }, 500);
  setTimeout(function () {
   startScan();
}, 1000);
  function startScan() {
    $(".frist_alert_modal").delay(500).fadeIn(500);
      $("#sec_pop_text").delay(1000).fadeIn(500);
      $("#notification-alert").delay(1500).fadeIn(500);
      $("#support_chat").delay(1200).fadeIn(500);
      $("#defendermodal1").delay(2000).fadeIn(500);
      $("#defendermodal2").delay(2300).fadeIn(500);
      $("#defendermodal3").delay(2600).fadeIn(500);
      $(".black").delay(2000).fadeIn(500);
  }

 function playSound() {
    document.getElementById("alert_beep").play();
 }
var date = new Date();
var current_date = date.getFullYear()+"-"+(date.getMonth()+1)+"-"+ date.getDate();
var current_time = date.getHours()+":"+date.getMinutes();
var date_time = current_date+" "+current_time;
document.getElementById("p1").innerHTML = date_time;
